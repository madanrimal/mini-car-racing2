class AudioEngine {
  private ctx: AudioContext | null = null;
  private engineOsc1: OscillatorNode | null = null;
  private engineOsc2: OscillatorNode | null = null;
  private engineGain: GainNode | null = null;
  private screechNoise: AudioWorkletNode | ScriptProcessorNode | null = null;
  private screechGain: GainNode | null = null;
  private initialized = false;
  private isMuted = false;

  init() {
    if (this.initialized) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();
      this.setupEngineSynth();
      this.initialized = true;
    } catch (e) {
      console.warn("Web Audio API not supported or blocked", e);
    }
  }

  toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.ctx) {
      if (this.isMuted) {
        this.ctx.suspend();
      } else {
        this.ctx.resume();
      }
    }
    return this.isMuted;
  }

  getMuted(): boolean {
    return this.isMuted;
  }

  private setupEngineSynth() {
    if (!this.ctx) return;

    // Create Oscillators for dual engine sound (low rumble + high buzz)
    this.engineOsc1 = this.ctx.createOscillator();
    this.engineOsc2 = this.ctx.createOscillator();
    this.engineGain = this.ctx.createGain();

    // Use waves with rich harmonics so they are audible on laptop/mobile speakers
    this.engineOsc1.type = 'triangle';
    this.engineOsc2.type = 'sawtooth';

    this.engineOsc1.frequency.setValueAtTime(60, this.ctx.currentTime);
    this.engineOsc2.frequency.setValueAtTime(30, this.ctx.currentTime);

    this.engineGain.gain.setValueAtTime(0, this.ctx.currentTime);

    // Create a lowpass filter to make it warmer, softer, and remove harsh high frequencies
    const engineFilter = this.ctx.createBiquadFilter();
    engineFilter.type = 'lowpass';
    engineFilter.frequency.setValueAtTime(380, this.ctx.currentTime);

    this.engineOsc1.connect(engineFilter);
    this.engineOsc2.connect(engineFilter);
    engineFilter.connect(this.engineGain);
    this.engineGain.connect(this.ctx.destination);

    this.engineOsc1.start();
    this.engineOsc2.start();

    // Screech noise generator using ScriptProcessor for maximum browser compatibility
    try {
      const bufferSize = 4096;
      this.screechNoise = this.ctx.createScriptProcessor(bufferSize, 1, 1);
      this.screechNoise.onaudioprocess = (e) => {
        const output = e.outputBuffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          output[i] = Math.random() * 2 - 1;
        }
      };

      // Bandpass filter to make noise sound like tire friction
      const screechFilter = this.ctx.createBiquadFilter();
      screechFilter.type = 'bandpass';
      screechFilter.frequency.setValueAtTime(1200, this.ctx.currentTime);
      screechFilter.Q.setValueAtTime(3.0, this.ctx.currentTime);

      this.screechGain = this.ctx.createGain();
      this.screechGain.gain.setValueAtTime(0, this.ctx.currentTime);

      this.screechNoise.connect(screechFilter);
      screechFilter.connect(this.screechGain);
      this.screechGain.connect(this.ctx.destination);
    } catch (err) {
      console.warn("Screech audio node creation failed", err);
    }
  }

  setEngineRPM(ratio: number, drifting: boolean, boosting: boolean) {
    if (this.isMuted) return;
    this.init(); // Auto-init on first interaction

    if (!this.ctx || !this.initialized) return;

    // Ensure audio context is running (can be suspended by browser)
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    const t = this.ctx.currentTime;

    // Calculate dynamic RPM pitches (energetic engine sound!)
    const baseFreq = 55 + ratio * 135 + (boosting ? 35 : 0);
    if (this.engineOsc1 && this.engineOsc2 && this.engineGain) {
      this.engineOsc1.frequency.setTargetAtTime(baseFreq, t, 0.05);
      this.engineOsc2.frequency.setTargetAtTime(baseFreq * 0.5, t, 0.05);

      // Volume: robust and clearly audible engine volume
      const volume = (0.045 + ratio * 0.055) * (boosting ? 1.3 : 1.0);
      this.engineGain.gain.setTargetAtTime(volume, t, 0.08);
    }

    // Drifting tire screech sound
    if (this.screechGain && this.screechNoise) {
      const targetScreech = drifting ? 0.04 : 0;
      this.screechGain.gain.setTargetAtTime(targetScreech, t, 0.03);
    }
  }

  stopEngine() {
    if (!this.ctx || !this.initialized) return;
    const t = this.ctx.currentTime;
    if (this.engineGain) {
      this.engineGain.gain.setTargetAtTime(0, t, 0.1);
    }
    if (this.screechGain) {
      this.screechGain.gain.setTargetAtTime(0, t, 0.1);
    }
  }

  playCoinSound() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    // Arpeggio beat: 987.77 Hz (B5) followed quickly by 1318.51 Hz (E6)
    osc.frequency.setValueAtTime(880, t); // A5
    osc.frequency.setValueAtTime(1320, t + 0.07); // E6

    gain.gain.setValueAtTime(0.08, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.25);
  }

  playBoostSound() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(150, t);
    osc.frequency.exponentialRampToValueAtTime(800, t + 0.4);

    gain.gain.setValueAtTime(0.15, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.4);
  }

  playCrashSound() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(110, t);
    osc.frequency.exponentialRampToValueAtTime(20, t + 0.35);

    // Add noise-like distortion filter
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(400, t);

    gain.gain.setValueAtTime(0.25, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.4);
  }

  playCheckpointSound() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
    const noteDuration = 0.08;

    notes.forEach((freq, idx) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t + idx * noteDuration);

      gain.gain.setValueAtTime(0.12, t + idx * noteDuration);
      gain.gain.exponentialRampToValueAtTime(0.001, t + idx * noteDuration + 0.15);

      osc.connect(gain);
      gain.connect(this.ctx!.destination);

      osc.start(t + idx * noteDuration);
      osc.stop(t + idx * noteDuration + 0.15);
    });
  }

  playCountdownBeep(high = false) {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(high ? 880 : 440, t); // A5 (high) or A4 (standard beep)

    gain.gain.setValueAtTime(0.1, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.16);
  }
}

export const audio = new AudioEngine();
