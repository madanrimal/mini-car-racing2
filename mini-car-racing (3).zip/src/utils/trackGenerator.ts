import { Track, TrackPoint, Checkpoint, Coin, Obstacle, Vector2D } from '../types';
import { catmullRom, vecAdd, vecSub, vecNormalize, vecRotate, vecScale, vecLen, vecDistance } from './math';

export interface GeneratorConfig {
  pointsCount: number; // e.g. 10 - 18
  radius: number; // e.g. 1000 - 1500 px
  turniness: number; // e.g. 0.1 - 0.5 (radius deviation)
  trackWidth: number; // e.g. 160 - 240 px
  obstacleDensity: number; // 0 to 1
  coinDensity: number; // 0 to 1
}

export function generateProceduralTrack(config: GeneratorConfig): Track {
  const { pointsCount, radius, turniness, trackWidth, obstacleDensity, coinDensity } = config;

  // For a straight track, we generate a high-resolution vertical road.
  // We'll map the radius parameter to length: e.g. radius * 14.5.
  const trackLength = radius * 14.5;
  const startY = 1000;
  const endY = startY - trackLength;

  const totalSamples = 1000;
  const trackPoints: TrackPoint[] = [];

  for (let i = 0; i < totalSamples; i++) {
    const t = i / (totalSamples - 1);
    const x = 0;
    const y = startY - t * trackLength;

    // Tangent goes straight up (decreasing Y)
    const tangent = { x: 0, y: -1 };
    // Normal is perpendicular (facing right, 90 deg clockwise of tangent)
    const normal = { x: 1, y: 0 };

    // Borders
    const left = { x: x - trackWidth / 2, y };
    const right = { x: x + trackWidth / 2, y };

    trackPoints.push({
      pos: { x, y },
      tangent,
      normal,
      left,
      right,
      index: i,
    });
  }

  const centerline = trackPoints.map(p => p.pos);

  // Define 4 sequential checkpoints going up the straight road
  const checkpoints: Checkpoint[] = [];
  const checkpointIndices = [250, 500, 750, 990]; // spread out up the highway
  checkpointIndices.forEach((ptIdx, idx) => {
    const pt = trackPoints[ptIdx];
    const angle = -Math.PI / 2; // facing straight up
    checkpoints.push({
      pos: pt.pos,
      width: trackWidth,
      angle,
      passed: false,
      index: idx,
    });
  });

  // Procedurally distribute coins along specific straight lanes: Left, Center, Right
  const coins: Coin[] = [];
  let coinIdCounter = 0;
  
  // Three lanes offsets based on track width
  const laneOffsets = [-trackWidth * 0.28, 0, trackWidth * 0.28];

  for (let i = 40; i < totalSamples - 40; i += 12) {
    if (Math.random() < coinDensity * 0.5) {
      // Choose a lane
      const laneIdx = Math.floor(Math.random() * 3);
      const laneOffset = laneOffsets[laneIdx];
      const chainCount = 4 + Math.floor(Math.random() * 4); // chains of 4 to 7 coins
      
      for (let j = 0; j < chainCount; j++) {
        const ptIdx = i + j * 3;
        if (ptIdx >= totalSamples - 30) continue;
        const pt = trackPoints[ptIdx];
        const coinPos = { x: pt.pos.x + laneOffset, y: pt.pos.y };

        coins.push({
          pos: coinPos,
          collected: false,
          id: `coin_${coinIdCounter++}`,
        });
      }
      i += chainCount * 3; // space out groups
    }
  }

  // Place exactly 2 special life control hearts in all levels (one at 50% progress, one at 85% progress)
  const heart50Idx = 500;
  if (heart50Idx > 0 && heart50Idx < totalSamples) {
    const pt50 = trackPoints[heart50Idx];
    coins.push({
      pos: { x: pt50.pos.x, y: pt50.pos.y },
      collected: false,
      id: `life_heart_50`,
      isLifeControl: true,
    });
  }

  const heart85Idx = 850;
  if (heart85Idx > 0 && heart85Idx < totalSamples) {
    const pt85 = trackPoints[heart85Idx];
    coins.push({
      pos: { x: pt85.pos.x, y: pt85.pos.y },
      collected: false,
      id: `life_heart_85`,
      isLifeControl: true,
    });
  }

  // Procedurally distribute obstacles (cones, barricades, oil, boost pads) aligned with lanes
  const obstacles: Obstacle[] = [];
  let obsIdCounter = 0;
  for (let i = 60; i < totalSamples - 60; i += 18) {
    if (Math.random() < obstacleDensity * 0.38) {
      const pt = trackPoints[i];
      // Pick a random lane
      const laneIdx = Math.floor(Math.random() * 3);
      const laneOffset = laneOffsets[laneIdx];
      const pos = { x: pt.pos.x + laneOffset, y: pt.pos.y };

      // Choose obstacle type
      const randType = Math.random();
      let type: 'cone' | 'barrier' | 'oil' | 'boost';
      let radiusObs = 15;

      if (randType < 0.25) {
        type = 'boost'; // Booster pad (beneficial!)
        radiusObs = 24;
      } else if (randType < 0.65) {
        type = 'oil'; // Slip hazard
        radiusObs = 28;
      } else {
        type = 'barrier'; // Large solid stop barrier
        radiusObs = 20;
      }

      // Check if too close to an existing checkpoint
      const nearCheckpoint = checkpoints.some(cp => vecDistance(pos, cp.pos) < 140);
      if (nearCheckpoint) continue;

      obstacles.push({
        id: `obs_${obsIdCounter++}`,
        pos,
        type,
        radius: radiusObs,
        angle: 0, // faced straight up
      });

      i += 12; // space out obstacles
    }
  }

  // Starting parameters at the bottom of the straight road
  const startPoint = { x: 0, y: startY };
  const startAngle = -Math.PI / 2; // pointing up

  return {
    points: trackPoints,
    centerline,
    checkpoints,
    coins,
    obstacles,
    width: trackWidth,
    startPoint,
    startAngle,
  };
}
